<?php
if ( ! defined( 'ABSPATH' ) )
	exit;
?>

<pre><?php print_r($data); ?></pre>