<div
  class="modal fade"
  id="modalList"
  tabindex="-1"
  role="dialog"
  aria-labelledby="modalListLabel"
  aria-hidden="true"
>
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <div class="modal-title">
          <span class="modalListLabel">¡Bienvenid@!</span>
        </div>
      </div>
      <div class="modal-body">
        <br />
        <div class="modal-subtitle">
          <span class="modalListDesc"
            >Elige el comercio en donde activarás tu checkout de Culqi</span
          >
        </div>
        <div class="form-group">
          <ul id='list-merchants' class="listaselect"></ul>
        </div>
      </div>
    </div>
  </div>
</div>
