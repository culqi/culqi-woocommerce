<label for="fullculqi_timexp">
	<input type="text" id="fullculqi_timexp" class="regular-text" name="fullculqi_options[time_expiration]" value="<?php echo esc_html($time_expiration); ?>"/> <br>
    <span class="form-text text-muted"> Ingresar el número de horas que tendrá el cliente para pagar su orden. Ejem: 24</span>
    <span id="errortimeexp" class="form-text text-muted" style="display: block; color: red"></span>
</label>
