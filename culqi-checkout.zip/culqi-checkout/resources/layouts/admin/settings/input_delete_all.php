<label for="fullculqi_delete_all">
	<button id="fullculqi_delete_all" class="fullculqi_delete_all button button-secondary button-hero"><?php esc_html_e(' Clear all', 'fullculqi' ); ?></button>
	<p class="help"><?php esc_html_e( 'Only will delete the information in your WordPress, not in Culqi. Use this option when you changes from development to live mode or from live mode to development.', 'fullculqi' ); ?></p>
	<div id="fullculqi_delete_all_notify"></div>
</label>