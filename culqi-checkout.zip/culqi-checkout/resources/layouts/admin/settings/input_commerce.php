<label for="fullculqi_commerce">
	<input type="text" id="fullculqi_commerce" class="regular-text" name="fullculqi_options[commerce]" value="<?php echo esc_html($commerce); ?>"/>
</label>
