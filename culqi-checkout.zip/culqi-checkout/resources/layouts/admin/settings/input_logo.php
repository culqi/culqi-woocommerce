<label for="fullculqi_logo">
	<input readonly type="text" id="fullculqi_logo" class="regular-text" name="fullculqi_options[logo_url]" value="<?php echo esc_html($logo_url); ?>"/>
    <br>
    <span class="form-text">
		<?php esc_html_e( 'Este logo aparecerá en tu Culqi Checkout', 'fullculqi' ); ?>
	</span>
</label>
