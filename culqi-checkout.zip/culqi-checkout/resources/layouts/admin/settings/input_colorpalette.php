
<label for="fullculqi_colorpalette">
	<input readonly type="text" id="fullculqi_colorpalette" class="regular-text" name="fullculqi_options[color_palette]" value="<?php echo esc_html($color_palette); ?>"/>
    <br>
	<span class="form-text">
		<?php esc_html_e( 'Utilizaremos estos colores para personalizar tu checkout.', 'fullculqi' ); ?>
	</span>
</label>
