<label for="fullculqi_seckey">
	<input required="true" type="text" id="fullculqi_seckey" class="regular-text" name="fullculqi_options[secret_key]" value="<?php echo esc_html($secret_key); ?>"/> <br>
	<span class="form-text text-muted"> Ingresa tu llave privada. </span>
    <span id="errorseckey" class="form-text text-muted" style="display: block; color: red"></span>
</label>
