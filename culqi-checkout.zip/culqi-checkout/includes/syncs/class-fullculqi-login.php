<?php
/**
 * Login Class
 * @since  1.0.0
 * @package Includes / Sync / Login
 */
class FullCulqi_Login {

/**
	 * Sync from Culqi
	 * @param  integer $records
	 * @return mixed
	 */
	public static function login( $email, $password ) {
		global $culqi;
    var_dump( $culqi );
  }


}