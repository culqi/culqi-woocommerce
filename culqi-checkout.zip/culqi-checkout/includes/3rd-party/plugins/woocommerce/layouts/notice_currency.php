<div class="error">
	<p><?php esc_html_e( 'Woocommerce Culqi Full Integration plugin needs the currency in the commerce be PEN or USD to work!', 'fullculqi' ); ?></p>
</div>